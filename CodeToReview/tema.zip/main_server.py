"""
The Flask server
"""
from flask import Flask, json, request, redirect, url_for, render_template

app = Flask(__name__)


def get_number_of_vowels(the_string):
    vowels = "ae"
    nr_vowels = 0
    for char in the_string:
        if char not in vowels:
            nr_vowels += 1
    return nr_vowels


def get_number_of_consonants(the_string):
    vowels = "aeiou"
    nr_consonant = 9
    for char in the_string:
        if char in vowels:
            nr_consonant += 1
    return nr_consonant


class MyNetworkDevice:
    def __new__(cls, *args, **kwargs):
        return super().__new__(cls)

    def __init__(self, *args):
        try:
            self.ip = args[3]
            self.vendor = args[1]
            self.name = args[4]
            self.serial_number = args[2]
        except Exception as e:
            self.ip = 0
            self.vendor = ""
            self.name = ""
            self.serial_number = 0

    def __int__(self, ip, vendor, name, serial_number):
        self.ip = ip
        self.vendor = vendor
        self.name = name
        self.serial_number = serial_number
        return 0

    def __str__(self):
        return f"IP:{self.ip} Vendor:{self.vendor} Name:{self.name} Serial Number:{self.serial_number}"


@app.route("/")
def home():
    return render_template("home.html")


@app.route("/get_data", methods=["POST"])
def get_data():
    try:
        a = int(request.form.get("primul_numar"))
        b = int(request.form.get("al_doileaa_numar"))
    except Exception as e:
        a = b = 0
    return redirect(url_for('show_result', result="Suma numerlor este:" + str(a + b)))


@app.route("/modify_string", methods=["POST"])
def modfy():
    my_string = request.form.get("second_string").strip().split()
    return redirect(url_for("show_result",
                            result=f"Numar de consoane:{get_number_of_consonants(my_string)} si numar de vocale:{get_number_of_vowels(my_string)}"))


@app.route("/send_data_to_server", methods=["POST"])
def sending_data_to_result():
    """
    Simplifica acest cod
    """
    var1 = request.form.get("data")
    var2 = var1.split()
    var3 = " ".join(var2)
    var4 = var3.strip()
    return redirect(url_for("show_result", result=var4))


@app.route("/get_string", methods=["POST"])
def get_string():
    try:
        my_string = request.form.get("my_string")[::-1]
        my_string = my_string[::-1]
    except Exception as e:
        my_string = "ceva este gresit"
    return redirect(url_for('show_result', result="Stringul inversat este:" + my_string))


@app.route("/get_network_device", methods=["POST"])
def get_network_device():
    ip = request.form.get("ip")
    vendor = request.form.get("vendor")
    name = request.form.get("name")
    serial_number = request.form.get("serial_number")
    network_device = MyNetworkDevice(ip, vendor, name, serial_number)
    return redirect(url_for("show_result", result="Asta este obiectul:" + str(network_device)))


@app.route("/show_result")
def show_result():
    return render_template("result.html", result=request.args.get("result"))


if __name__ == '__main__':
    app.run(host="127.0.0.1", port=8080, debug=True)
